@extends('admin.index')
 

@section('body')  
 

 <img src="{{asset('fontpage/img/logo/M IT FARM1  Mobile  Logo.png')}} "  width="100%;"  alt="">

@endsection