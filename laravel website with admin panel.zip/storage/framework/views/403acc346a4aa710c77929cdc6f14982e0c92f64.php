 

<?php $__env->startSection('body'); ?>  
 

 <img src="<?php echo e(asset('fontpage/img/logo/M IT FARM1  Mobile  Logo.png')); ?> "  width="100%;"  alt="">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\laravel website with admin panel\resources\views/admin/layout.blade.php */ ?>