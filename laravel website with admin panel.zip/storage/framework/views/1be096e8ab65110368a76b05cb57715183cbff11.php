 <?php $__env->startSection('title'); ?>

         <?php
     $title = DB::table('titleandtags')->first(); ?>
      <title> <?php echo e($title->title); ?> </title>
    <meta  name="keywords" content="<?php echo e($title->tags); ?> ">
    <meta name="description" content="<?php echo e($title->deteles); ?> ">
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>  

<meta name="viewport" content="width=device-width, initial-scale=1.0">
 <br>
 <br>
 <br>
 <br>
 <br>
 
 <div class="main_detels">
 	
 	<div class="full_deteles">
 		<img class="deteles_img" src="<?php echo e(url('fontpage/img/logo/mit background.png')); ?> " width="100%" height="300px;" alt="">
 		<h2 class="deteles_h2"><a href="<?php echo e(route('home/mitfarm')); ?>">HOME</a> -> About Us 
    
 		</h2>

 	</div>
 </div>

  <div class="main_about">
  	<div class="about_us">
  		
  		 
  		<h3 class="abtitle"><?php echo e($title->title); ?></h3>
  		<hr>
  		<p class="abdeteles"><?php echo e($title->deteles); ?> </p>
  	</div>
  </div>
 

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\mitadda\resources\views/about.blade.php */ ?>