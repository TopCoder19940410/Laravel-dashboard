<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class base extends Model
{
    //
}
